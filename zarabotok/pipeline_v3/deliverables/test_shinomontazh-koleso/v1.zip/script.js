/**
 * script.js — Логика интерфейса для лендинга «Колесо»
 * 
 * Функционал:
 * 1. Управление мобильным меню (бургер-кнопка, анимация открытия).
 * 2. Плавный скролл к якорям с учетом фиксированного хедера.
 * 3. Автоматическое закрытие меню при клике вне его области.
 */

document.addEventListener('DOMContentLoaded', () => {
    // --- Конфигурация (можно менять в одном месте) ---
    const HEADER_OFFSET = 80; // Высота фиксированного хедера в пикселях
    
    // --- Элементы управления меню ---
    const burgerBtn = document.querySelector('.burger-btn');
    const mobileMenu = document.querySelector('.mobile-menu');

    if (burgerBtn && mobileMenu) {
        // Открытие/закрытие по клику на кнопку
        burgerBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('open');
            burgerBtn.classList.toggle('active');
            
            // Блокируем прокрутку основного контента при открытом меню (опционально)
            document.body.style.overflow = mobileMenu.classList.contains('open') ? 'hidden' : '';
        });

        // Закрытие меню при клике в любое место, кроме самого меню и кнопки
        const closeOnOutsideClick = () => {
            if (!mobileMenu.classList.contains('open')) return;
            
            document.body.style.overflow = ''; // Возвращаем прокрутку
            
            burgerBtn.classList.remove('active');
            mobileMenu.classList.remove('open');
            document.body.style.overflow = '';
        };

        document.addEventListener('click', (e) => {
            if (!mobileMenu.contains(e.target) && !burgerBtn.contains(e.target)) {
                closeOnOutsideClick();
            }
        });

        // Закрытие по клавиатуре (Enter/Space) для доступности
        burgerBtn.setAttribute('aria-expanded', 'false');
        burgerBtn.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeOnOutsideClick();
            }
        });
    }

    // --- Плавный скролл к якорям ---
    const navLinks = document.querySelectorAll('.main-nav a[href^="#"]');

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            const targetId = link.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);

            if (targetSection) {
                // Вычисляем позицию элемента относительно окна просмотра
                const elementPosition = targetSection.getBoundingClientRect().top + window.pageYOffset;
                
                // Корректируем на высоту хедера, чтобы секция не "уходила" под него
                const correctedPosition = elementPosition - HEADER_OFFSET;

                // Выполняем плавный скролл
                window.scrollTo({
                    top: correctedPosition,
                    behavior: 'smooth'
                });

                // Обновляем состояние кнопки бургера (закрываем меню после перехода)
                if (mobileMenu.classList.contains('open')) {
                    closeOnOutsideClick();
                }
            }
        });
    });
});
